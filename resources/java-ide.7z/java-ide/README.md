please add presentation and project example

Please add any other info needed here